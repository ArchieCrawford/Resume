console.log(`
Next steps:
1) npm install
2) npm run generate:pdf   # builds public/Archie_Crawford_Resume.pdf from public/resume.html
3) npm run dev            # open http://localhost:3000
Optional: replace /public/screens/*.png with real screenshots.
`);
